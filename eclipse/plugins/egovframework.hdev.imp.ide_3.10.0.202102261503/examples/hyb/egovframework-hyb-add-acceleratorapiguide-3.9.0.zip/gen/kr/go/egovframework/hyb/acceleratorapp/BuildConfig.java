/** Automatically generated file. DO NOT MODIFY */
package kr.go.egovframework.hyb.acceleratorapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}