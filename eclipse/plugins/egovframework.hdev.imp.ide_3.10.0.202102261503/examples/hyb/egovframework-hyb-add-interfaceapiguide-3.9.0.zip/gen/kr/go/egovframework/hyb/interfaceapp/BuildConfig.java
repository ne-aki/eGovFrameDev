/** Automatically generated file. DO NOT MODIFY */
package kr.go.egovframework.hyb.interfaceapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}