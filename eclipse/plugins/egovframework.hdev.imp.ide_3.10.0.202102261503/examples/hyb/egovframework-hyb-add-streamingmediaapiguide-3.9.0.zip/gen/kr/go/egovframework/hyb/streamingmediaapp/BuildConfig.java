/** Automatically generated file. DO NOT MODIFY */
package kr.go.egovframework.hyb.streamingmediaapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}